from ui.ui import *

ui = UserInterface()

ui.start()


