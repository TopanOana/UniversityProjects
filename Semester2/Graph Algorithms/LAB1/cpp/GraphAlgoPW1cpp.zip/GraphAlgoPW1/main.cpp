#include <iostream>
#include "UserInterface.h"

int main() {
    UserInterface ui;
    ui.start();
    //std::cout << "Hello, World!" << std::endl;
    return 0;
}
